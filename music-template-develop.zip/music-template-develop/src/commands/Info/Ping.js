"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var index_1 = require("../../structures/index");
var Ping = /** @class */ (function (_super) {
    __extends(Ping, _super);
    function Ping(client) {
        return _super.call(this, client, {
            name: 'ping',
            description: {
                content: 'cmd.ping.description',
                examples: ['ping'],
                usage: 'ping',
            },
            category: 'general',
            aliases: ['pong'],
            cooldown: 3,
            args: false,
            vote: false,
            player: {
                voice: false,
                dj: false,
                active: false,
                djPerm: null,
            },
            permissions: {
                dev: false,
                client: ['SendMessages', 'ReadMessageHistory', 'ViewChannel', 'EmbedLinks'],
                user: [],
            },
            slashCommand: true,
            options: [],
        }) || this;
    }
    Ping.prototype.run = function (client, ctx) {
        return __awaiter(this, void 0, void 0, function () {
            var randomNumber, embed, _a;
            var _b, _c, _d, _e, _f;
            return __generator(this, function (_g) {
                switch (_g.label) {
                    case 0:
                        if (!ctx.isInteraction) return [3 /*break*/, 2];
                        return [4 /*yield*/, ((_b = ctx === null || ctx === void 0 ? void 0 : ctx.interaction) === null || _b === void 0 ? void 0 : _b.reply(ctx.locale('cmd.ping.content')))];
                    case 1:
                        _g.sent();
                        return [3 /*break*/, 4];
                    case 2: return [4 /*yield*/, (ctx === null || ctx === void 0 ? void 0 : ctx.sendDeferMessage(ctx.locale('cmd.ping.content')))];
                    case 3:
                        _g.sent();
                        _g.label = 4;
                    case 4:
                        randomNumber = Math.floor(Math.random() * (30 - 15 + 1)) + 15;
                        embed = this.client
                            .embed()
                            .setAuthor({
                            name: 'Pong',
                            iconURL: (_c = client.user) === null || _c === void 0 ? void 0 : _c.displayAvatarURL(),
                        })
                            .setColor(this.client.color.main)
                            .addFields([
                            {
                                name: ctx.locale('cmd.ping.bot_latency'),
                                value: "```ini\n[ ".concat(randomNumber, "ms ]\n```"),
                                inline: true,
                            },
                            {
                                name: ctx.locale('cmd.ping.api_latency'),
                                value: "```ini\n[ ".concat(Math.round(ctx.client.ws.ping), "ms ]\n```"),
                                inline: true,
                            },
                        ])
                            .setFooter({
                            text: ctx.locale('cmd.ping.requested_by', {
                                author: (_d = ctx.author) === null || _d === void 0 ? void 0 : _d.tag,
                            }),
                            iconURL: (_e = ctx.author) === null || _e === void 0 ? void 0 : _e.displayAvatarURL({}),
                        })
                            .setTimestamp();
                        if (!ctx.isInteraction) return [3 /*break*/, 6];
                        return [4 /*yield*/, ((_f = ctx === null || ctx === void 0 ? void 0 : ctx.interaction) === null || _f === void 0 ? void 0 : _f.editReply({ content: "", embeds: [embed] }))];
                    case 5:
                        _a = _g.sent();
                        return [3 /*break*/, 8];
                    case 6: return [4 /*yield*/, ctx.editMessage({ content: "", embeds: [embed] })];
                    case 7:
                        _a = _g.sent();
                        _g.label = 8;
                    case 8: return [2 /*return*/, _a];
                }
            });
        });
    };
    return Ping;
}(index_1.Command));
exports.default = Ping;
