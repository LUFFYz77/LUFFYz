"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var discord_js_1 = require("discord.js");
var index_1 = require("../../structures/index");
var Search = /** @class */ (function (_super) {
    __extends(Search, _super);
    function Search(client) {
        return _super.call(this, client, {
            name: 'search',
            description: {
                content: 'cmd.search.description',
                examples: ['search example'],
                usage: 'search <song>',
            },
            category: 'music',
            aliases: ['sc'],
            cooldown: 3,
            args: true,
            vote: true,
            player: {
                voice: true,
                dj: false,
                active: false,
                djPerm: null,
            },
            permissions: {
                dev: false,
                client: ['SendMessages', 'ReadMessageHistory', 'ViewChannel', 'EmbedLinks'],
                user: [],
            },
            slashCommand: true,
            options: [
                {
                    name: 'song',
                    description: 'cmd.search.options.song',
                    type: 3,
                    required: true,
                },
            ],
        }) || this;
    }
    Search.prototype.run = function (client, ctx, args) {
        return __awaiter(this, void 0, void 0, function () {
            var embed, player, query, memberVoiceChannel, response, selectMenu, row, embeds, collector;
            var _this = this;
            var _a;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        embed = this.client.embed().setColor(this.client.color.main);
                        player = client.manager.getPlayer(ctx.guild.id);
                        query = args.join(' ');
                        memberVoiceChannel = ctx.member.voice.channel;
                        if (!player)
                            player = client.manager.createPlayer({
                                guildId: ctx.guild.id,
                                voiceChannelId: memberVoiceChannel.id,
                                textChannelId: ctx.channel.id,
                                selfMute: false,
                                selfDeaf: true,
                                vcRegion: memberVoiceChannel.rtcRegion,
                            });
                        if (!!player.connected) return [3 /*break*/, 2];
                        return [4 /*yield*/, player.connect()];
                    case 1:
                        _b.sent();
                        _b.label = 2;
                    case 2: return [4 /*yield*/, player.search({ query: query }, ctx.author)];
                    case 3:
                        response = (_b.sent());
                        if (!(!response || ((_a = response.tracks) === null || _a === void 0 ? void 0 : _a.length) === 0)) return [3 /*break*/, 5];
                        return [4 /*yield*/, ctx.sendMessage({
                                embeds: [embed.setDescription(ctx.locale('cmd.search.errors.no_results')).setColor(this.client.color.red)],
                            })];
                    case 4: return [2 /*return*/, _b.sent()];
                    case 5:
                        selectMenu = new discord_js_1.StringSelectMenuBuilder()
                            .setCustomId('select-track')
                            .setPlaceholder(ctx.locale('cmd.search.select'))
                            .addOptions(response.tracks.slice(0, 10).map(function (track, index) { return ({
                            label: "".concat(index + 1, ". ").concat(track.info.title),
                            description: track.info.author,
                            value: index.toString(),
                        }); }));
                        row = new discord_js_1.ActionRowBuilder().addComponents(selectMenu);
                        if (!(response.loadType === 'search' && response.tracks.length > 5)) return [3 /*break*/, 7];
                        embeds = response.tracks.map(function (track, index) {
                            return "".concat(index + 1, ". [").concat(track.info.title, "](").concat(track.info.uri, ") - `").concat(track.info.author, "`");
                        });
                        return [4 /*yield*/, ctx.sendMessage({
                                embeds: [embed.setDescription(embeds.join('\n'))],
                                components: [row],
                            })];
                    case 6:
                        _b.sent();
                        _b.label = 7;
                    case 7:
                        collector = ctx.channel.createMessageComponentCollector({
                            filter: function (f) { var _a; return f.user.id === ((_a = ctx.author) === null || _a === void 0 ? void 0 : _a.id); },
                            max: 1,
                            time: 60000,
                            idle: 60000 / 2,
                        });
                        collector.on('collect', function (int) { return __awaiter(_this, void 0, void 0, function () {
                            var track;
                            return __generator(this, function (_a) {
                                switch (_a.label) {
                                    case 0:
                                        track = response.tracks[Number.parseInt(int.values[0])];
                                        return [4 /*yield*/, int.deferUpdate()];
                                    case 1:
                                        _a.sent();
                                        if (!track)
                                            return [2 /*return*/];
                                        player.queue.add(track);
                                        if (!(!player.playing && player.queue.tracks.length > 0)) return [3 /*break*/, 3];
                                        return [4 /*yield*/, player.play({ paused: false })];
                                    case 2:
                                        _a.sent();
                                        _a.label = 3;
                                    case 3: return [4 /*yield*/, ctx.editMessage({
                                            embeds: [
                                                embed.setDescription(ctx.locale('cmd.search.messages.added_to_queue', {
                                                    title: track.info.title,
                                                    uri: track.info.uri,
                                                })),
                                            ],
                                            components: [],
                                        })];
                                    case 4:
                                        _a.sent();
                                        return [2 /*return*/, collector.stop()];
                                }
                            });
                        }); });
                        collector.on('end', function () { return __awaiter(_this, void 0, void 0, function () {
                            return __generator(this, function (_a) {
                                switch (_a.label) {
                                    case 0: return [4 /*yield*/, ctx.editMessage({ components: [] })];
                                    case 1:
                                        _a.sent();
                                        return [2 /*return*/];
                                }
                            });
                        }); });
                        return [2 /*return*/];
                }
            });
        });
    };
    return Search;
}(index_1.Command));
exports.default = Search;
